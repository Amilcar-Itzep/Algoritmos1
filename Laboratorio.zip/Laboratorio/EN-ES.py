# Función para cargar el diccionario de traducciones desde el archivo
def cargar_traducciones(archivo):
    traducciones = {}
    try:
        with open(archivo, 'r') as f:
            for linea in f:
                linea = linea.strip()
                if '=' in linea:
                    palabra_ing, palabra_esp = linea.split('=')
                    traducciones[palabra_ing.strip()] = palabra_esp.strip()
    except FileNotFoundError:
        print(f"El archivo {archivo} no existe. Se creará uno nuevo.")
    return traducciones

# Función para guardar el diccionario actualizado en el archivo
def guardar_traducciones(archivo, traducciones):
    with open(archivo, 'w') as f:
        for palabra_ing, palabra_esp in traducciones.items():
            f.write(f"{palabra_ing}={palabra_esp}\n")

# Función para agregar una nueva traducción
def agregar_traduccion(archivo, palabra_ing, palabra_esp):
    traducciones = cargar_traducciones(archivo)
    traducciones[palabra_ing] = palabra_esp
    guardar_traducciones(archivo, traducciones)
    print(f"Traducción agregada: {palabra_ing} -> {palabra_esp}")

# Función para traducir según los códigos de idioma
def traducir(archivo, codigo_origen, codigo_destino, palabra):
    traducciones = cargar_traducciones(archivo)
    
    if codigo_origen == "EN" and codigo_destino == "ES":
        return traducciones.get(palabra, f"Traducción no encontrada para '{palabra}'")
    elif codigo_origen == "ES" and codigo_destino == "EN":
        for ing, esp in traducciones.items():
            if esp == palabra:
                return ing
        return f"Traducción no encontrada para '{palabra}'"
    else:
        return "Códigos de idioma no soportados. Usa 'EN' o 'ES'."

# Archivo de traducciones
archivo_traducciones = "EN-ES.txt"

# Agregar traducciones de animales
agregar_traduccion(archivo_traducciones, "mouse", "ratón")
agregar_traduccion(archivo_traducciones, "horse", "caballo")
agregar_traduccion(archivo_traducciones, "elephant", "elefante")
agregar_traduccion(archivo_traducciones, "lion", "león")
agregar_traduccion(archivo_traducciones, "tiger", "tigre")

# Traducir del inglés al español
print(traducir(archivo_traducciones, "EN", "ES", "lion"))  # león
print(traducir(archivo_traducciones, "EN", "ES", "tiger"))  # tigre

# Traducir del español al inglés
print(traducir(archivo_traducciones, "ES", "EN", "ratón"))  # mouse
print(traducir(archivo_traducciones, "ES", "EN", "elefante"))  # elephant
