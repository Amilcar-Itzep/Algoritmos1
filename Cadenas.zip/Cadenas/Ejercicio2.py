# Solicitar el nombre completo del usuario
nombre_completo = input("Introduce tu nombre completo: ")

# Imprimir el nombre completo en minúsculas
print(nombre_completo.lower())

# Imprimir el nombre completo en mayúsculas
print(nombre_completo.upper())

# Imprimir el nombre completo con la primera letra de cada palabra en mayúscula
print(nombre_completo.title())
