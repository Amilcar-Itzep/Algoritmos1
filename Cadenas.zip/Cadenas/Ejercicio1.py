# Solicitar el nombre del usuario
nombre = input("Introduce tu nombre: ")

# Solicitar un número entero
numero = int(input("Introduce un número entero: "))

# Imprimir el nombre del usuario tantas veces como el número introducido
for _ in range(numero):
    print(nombre)
