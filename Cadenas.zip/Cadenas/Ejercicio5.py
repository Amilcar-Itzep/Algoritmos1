# Solicitar una frase al usuario
frase = input("Introduce una frase: ")

# Invertir la frase
frase_invertida = frase[::-1]

# Mostrar la frase invertida
print(f"La frase invertida es: {frase_invertida}")
