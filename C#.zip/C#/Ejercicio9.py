# Inicializar la variable de acumulación
acumulado = 0

# Bucle para ingresar valores hasta que se ingrese 9999
while True:
    valor = int(input("Ingrese un valor (9999 para finalizar): "))
    
    if valor == 9999:
        # Termina la carga cuando se ingresa 9999
        break
    else:
        # Acumula el valor ingresado
        acumulado += valor

# Mostrar el valor acumulado
print(f"El valor acumulado es: {acumulado}")

# Informar si es cero, mayor a cero o menor a cero
if acumulado == 0:
    print("El valor acumulado es igual a cero.")
elif acumulado > 0:
    print("El valor acumulado es mayor a cero.")
else:
    print("El valor acumulado es menor a cero.")
