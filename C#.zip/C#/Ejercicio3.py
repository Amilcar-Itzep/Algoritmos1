# Función para determinar la cantidad de dígitos de un número
def contar_digitos(numero):
    if 0 <= numero <= 9:
        return 1
    elif 10 <= numero <= 99:
        return 2
    elif 100 <= numero <= 999:
        return 3
    else:
        return -1  # Número con más de 3 dígitos

# Solicitar al usuario que ingrese un número entero positivo
numero = int(input("Ingrese un número entero positivo de hasta tres dígitos: "))

# Verificar la cantidad de dígitos y mostrar el mensaje correspondiente
digitos = contar_digitos(numero)

if digitos == 1:
    print("El número tiene 1 dígito.")
elif digitos == 2:
    print("El número tiene 2 dígitos.")
elif digitos == 3:
    print("El número tiene 3 dígitos.")
else:
    print("Error: El número ingresado tiene más de 3 dígitos o es negativo.")
