# Función para determinar el cuadrante de un punto
def determinar_cuadrante(x, y):
    if x > 0 and y > 0:
        return "1º Cuadrante"
    elif x < 0 and y > 0:
        return "2º Cuadrante"
    elif x < 0 and y < 0:
        return "3º Cuadrante"
    elif x > 0 and y < 0:
        return "4º Cuadrante"
    else:
        return "El punto está sobre un eje, no en un cuadrante"

# Solicitar al usuario que ingrese las coordenadas del punto
x = int(input("Ingrese la coordenada X (distinta de 0): "))
y = int(input("Ingrese la coordenada Y (distinta de 0): "))

# Verificar que las coordenadas sean distintas de cero
if x == 0 or y == 0:
    print("Error: Las coordenadas no deben ser iguales a cero.")
else:
    # Determinar y mostrar el cuadrante
    cuadrante = determinar_cuadrante(x, y)
    print(f"El punto ({x}, {y}) está en el {cuadrante}.")
