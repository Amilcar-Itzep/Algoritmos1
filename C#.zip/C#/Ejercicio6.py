# Solicitar sueldo y años de antigüedad al operario
sueldo = float(input("Ingrese el sueldo del operario: "))
antiguedad = int(input("Ingrese los años de antigüedad del operario: "))

# Evaluar las condiciones para determinar el aumento o no
if sueldo < 500:
    if antiguedad >= 10:
        # Aumento del 20%
        aumento = sueldo * 0.20
        sueldo_a_pagar = sueldo + aumento
        print(f"Se otorga un aumento del 20%. Sueldo a pagar: {sueldo_a_pagar}")
    else:
        # Aumento del 5%
        aumento = sueldo * 0.05
        sueldo_a_pagar = sueldo + aumento
        print(f"Se otorga un aumento del 5%. Sueldo a pagar: {sueldo_a_pagar}")
else:
    # Sueldo sin cambios
    print(f"El sueldo es de {sueldo}, no se aplica ningún aumento.")
