# Función para calcular el porcentaje de respuestas correctas
def calcular_porcentaje(correctas, total):
    return (correctas / total) * 100

# Función para determinar el nivel del postulante según el porcentaje
def determinar_nivel(porcentaje):
    if porcentaje >= 90:
        return "Nivel máximo"
    elif porcentaje >= 75:
        return "Nivel medio"
    elif porcentaje >= 50:
        return "Nivel regular"
    else:
        return "Fuera de nivel"

# Solicitar la cantidad total de preguntas y respuestas correctas al usuario
total_preguntas = int(input("Ingrese la cantidad total de preguntas: "))
respuestas_correctas = int(input("Ingrese la cantidad de respuestas correctas: "))

# Verificar que las respuestas correctas no superen el total de preguntas
if respuestas_correctas > total_preguntas:
    print("Error: La cantidad de respuestas correctas no puede ser mayor que el total de preguntas.")
else:
    # Calcular el porcentaje de respuestas correctas
    porcentaje = calcular_porcentaje(respuestas_correctas, total_preguntas)
    
    # Determinar el nivel del postulante
    nivel = determinar_nivel(porcentaje)
    
    # Mostrar el resultado
    print(f"El porcentaje de respuestas correctas es: {porcentaje:.2f}%")
    print(f"Nivel del postulante: {nivel}")
