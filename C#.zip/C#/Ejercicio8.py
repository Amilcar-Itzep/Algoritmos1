# Imprimir los múltiplos de 8 hasta 500
for i in range(8, 501, 8):
    print(i, end=" - ")
