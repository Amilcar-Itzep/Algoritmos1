# Solicitar la cantidad de números a ingresar
n = int(input("Ingrese la cantidad de números enteros a cargar: "))

# Inicializar los contadores para pares e impares
pares = 0
impares = 0

# Ciclo para ingresar los números
for i in range(n):
    numero = int(input(f"Ingrese el número {i + 1}: "))
    
    # Verificar si el número es par o impar
    if numero % 2 == 0:
        pares += 1
    else:
        impares += 1

# Mostrar el resultado
print(f"Cantidad de números pares: {pares}")
print(f"Cantidad de números impares: {impares}")
