# Función para calcular el perímetro de un cuadrado
def calcular_perimetro(lado):
    return lado * 4

# Solicitar al usuario que ingrese el valor del lado del cuadrado
lado = float(input("Ingrese el valor del lado del cuadrado: "))

# Calcular el perímetro
perimetro = calcular_perimetro(lado)

# Mostrar el perímetro
print(f"El perímetro del cuadrado es: {perimetro}")
