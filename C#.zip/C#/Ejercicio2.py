# Función para calcular el total a pagar
def calcular_total(precio, cantidad):
    return precio * cantidad

# Solicitar al usuario que ingrese el precio del artículo
precio = float(input("Ingrese el precio del artículo: "))

# Solicitar al usuario que ingrese la cantidad que lleva el cliente
cantidad = int(input("Ingrese la cantidad que lleva el cliente: "))

# Calcular el total a pagar
total = calcular_total(precio, cantidad)

# Mostrar el total que debe abonar el comprador
print(f"El total a pagar es: ${total:.2f}")
