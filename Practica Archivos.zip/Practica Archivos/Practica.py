def calcular_promedios(alumnos):
    resultados = {}
    for alumno in alumnos:
        datos = alumno.split(',')
        nombre = datos[0]
        notas = list(map(int, datos[1:]))
        promedio = sum(notas) // len(notas)
        resultados[nombre] = promedio
    return resultados

def guardar_resultados(resultados, archivo):
    with open(archivo, 'w') as f:
        for nombre, promedio in resultados.items():
            f.write(f"{nombre}={promedio}\n")

if __name__ == "__main__":    
    # Pedir al usuario la lista de alumnos y notas
    datos_alumnos = input("Introduce la lista de alumnos y sus notas: ")
    
    # Validar que se introdujo algo
    if not datos_alumnos:
        print("Error: Debes proporcionar la lista de alumnos y sus notas.")
        sys.exit(1)
    
    # Procesar los datos
    alumnos = datos_alumnos.split('|')
    
    # Calcular promedios
    promedios = calcular_promedios(alumnos)
    
    # Guardar resultados en un archivo
    guardar_resultados(promedios, 'resultados.txt')
    print("Los promedios han sido guardados en 'resultados.txt'")
