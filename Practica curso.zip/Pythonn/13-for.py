lenguajes = ["Python", "Ruby", "PHP", "Javascript", "Java"]

for lenguajes in lenguajes:
    print(lenguajes)

i = 0
while 1 < len(lenguajes):
    print(lenguajes[i])
    i = i + 1
