lenguajes = ["Python", "Ruby", "PHP", "Javascript", "Java"]
lenguajes.insert(3, "Go")
lenguajes.insert(0, "C")
lenguajes.remove("Ruby")
print("PHP" in lenguajes)


print(len(lenguajes))