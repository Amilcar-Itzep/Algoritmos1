variable = "Hola Mundo"
numero = 42
decimal = 10.5 
verdadero = True
false = False 