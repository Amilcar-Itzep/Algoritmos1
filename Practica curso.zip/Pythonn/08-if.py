puntaje = 97

if puntaje >= 95:
    print("Aprobado con honores")
elif puntaje >= 50:
    print("Alumno aprobado")
else:
    print("Reprobado")

print("Fuera del if")    